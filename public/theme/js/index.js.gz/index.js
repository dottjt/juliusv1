
addEventListener(hover(function() {
	var tim = document.createElement("span");
	tim.classList.add("hello");
}, function() {
	var yo = document.getElementsByClassName("hello").parentNode;
		yo.removeChild(document.getElementsByClassName("hello");

});	 work, false)

